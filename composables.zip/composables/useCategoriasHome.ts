// composables/useCategoriasHome.ts

// composables/useCategoriasHome.ts
export const useCategoriasHome = async () => {
  return await queryCollection('categorias')
    .where('type', '=', 'categoria')
    .all()
}

