// composables/useProductosByCategoria.ts
import { useAsyncData, useRoute } from '#imports'
import { queryCollection } from '@nuxt/content'
import type { Producto } from '@/types'

export const useProductosByCategoria = () => {
  const route = useRoute()
  const searchPath = route.path
  const asyncDataKey = `productos-en-${searchPath.replace(/\//g, '-')}`

  return useAsyncData(asyncDataKey, async () => {
    try {
      const products = await queryCollection('categorias')
        .where('_path', 'LIKE', `${searchPath}/%`)
        .where('_path', '<>', `${searchPath}/index`)
        .where('type', '=', 'producto')
        .select('_path', 'title', 'slug', 'image', 'alt')
        .order('order', 'ASC')
        .order('title', 'ASC')
        .find()

      return products
    } catch (e) {
      console.error(`[useProductosByCategoria] Error buscando productos en ${searchPath}:`, e)
      return []
    }
  })
}
