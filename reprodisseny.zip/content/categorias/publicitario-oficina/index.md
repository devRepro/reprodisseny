---
alt: Material publicitario y de oficina diverso impreso
brand: Repro Disseny
description: >-
  Soluciones integrales de impresión para publicidad y oficina. Material
  promocional, papelería corporativa y más.
faqs: []
featured: false
formFields: []
galleryImages: []
image: publicidad.webp
inStock: true
keywords:
  - publicidad impresa barcelona
  - material oficina personalizado
  - papelería corporativa
  - impresión flyers cataluña
metaDescription: >-
  Impresión de material publicitario y de oficina: flyers, trípticos, carpetas,
  blocs, papelería corporativa y más en Barcelona.
metaTitle: Publicidad y Material de Oficina Personalizado | Repro Disseny
nav: Publicidad y Oficina
order: 2
path: /categorias/publicitario-oficina
priceCurrency: EUR
ratingValue: 4.7
reviewCount: 164
schema:
  '@type': CollectionPage
  name: Publicidad y Material de Oficina Personalizado | Repro Disseny
  description: Soluciones integrales de impresión para publicidad y oficina...
  image: 'https://reprodisseny.com/img/categorias/publicidad.webp'
  url: 'https://reprodisseny.com/categorias/publicitario-oficina'
  brand:
    '@type': Organization
    name: Repro Disseny
schemaType: CollectionPage
searchTerms:
  - imprenta publicidad barcelona
  - material oficina empresas
slug: publicitario-oficina
title: Publicidad y Material de Oficina Personalizado
type: categoria
---

## Publicidad y Material de Oficina Personalizado
Texto introductorio para la categoría general...
