---
title: Folletos plegados
metaTitle: Folletos plegados | Repro Disseny
metaDescription: Folletos plegados personalizadas con calidad profesional en Cataluña.
keywords:
  - folletos plegados
searchTerms:
  - folletos plegados
image: /img/productos/Folletos-plegados.webp
galleryImages: []
alt: alt descripció de la foto
slug: folletos-plegados
category: material-oficina
sku: 01-OFICI-0006
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Folletos plegados
  description: ''
  image: 'https://reprodisseny.com/img/productos/Folletos-plegados.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-oficina/folletos-plegados
  sku: 01-OFICI-0006
  mpn: REF-01-OFICI-0006
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

