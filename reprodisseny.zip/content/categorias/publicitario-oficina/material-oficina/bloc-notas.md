---
title: Bloc de notas
metaTitle: Bloc de notas | Repro Disseny
metaDescription: Bloc de notas personalizadas con calidad profesional en Cataluña.
keywords:
  - bloc de notas
searchTerms:
  - bloc de notas
image: /img/productos/bloc-de-notas.webp
galleryImages: []
alt: alt descripció de la foto
slug: bloc-notas
category: material-oficina
sku: 01-OFICI-0021
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Bloc de notas
  description: ''
  image: 'https://reprodisseny.com/img/productos/bloc-de-notas.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-oficina/bloc-notas
  sku: 01-OFICI-0021
  mpn: REF-01-OFICI-0021
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---
s
