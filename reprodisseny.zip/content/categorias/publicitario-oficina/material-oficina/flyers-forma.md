---
title: Flyers con forma
metaTitle: Flyers con forma | Repro Disseny
metaDescription: Flyers con forma personalizadas con calidad profesional en Cataluña.
keywords:
  - flyers con forma
searchTerms:
  - flyers con forma
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: flyers-forma
category: material-oficina
sku: 01-OFICI-0003
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Flyers con forma
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-oficina/flyers-forma
  sku: 01-OFICI-0003
  mpn: REF-01-OFICI-0003
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

