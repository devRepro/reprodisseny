---
title: Tarjetas de pvc
metaTitle: Tarjetas de pvc | Repro Disseny
metaDescription: Tarjetas de pvc personalizadas con calidad profesional en Cataluña.
keywords:
  - tarjetas de pvc
searchTerms:
  - tarjetas de pvc
image: /img/productos/tarjetas-pvc.webp
galleryImages: []
alt: alt descripció de la foto
slug: tarjetas-pvc
category: material-publicitario
sku: 01-OFICI-0013
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Tarjetas de pvc
  description: ''
  image: 'https://reprodisseny.com/img/productos/tarjetas-pvc.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-publicitario/tarjetas-pvc
  sku: 01-OFICI-0013
  mpn: REF-01-OFICI-0013
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

