---
title: Tazas
metaTitle: Tazas | Repro Disseny
metaDescription: Tazas personalizadas con calidad profesional en Cataluña.
keywords:
  - tazas
searchTerms:
  - tazas
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: tazas
category: material-publicitario
sku: 01-OFICI-0027
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Tazas
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-publicitario/tazas
  sku: 01-OFICI-0027
  mpn: REF-01-OFICI-0027
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

