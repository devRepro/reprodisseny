---
title: Libretas
metaTitle: Libretas | Repro Disseny
metaDescription: Libretas personalizadas con calidad profesional en Cataluña.
keywords:
  - libretas
searchTerms:
  - libretas
image: /img/productos/libretas.webp
galleryImages: []
alt: alt descripció de la foto
slug: libretas
category: material-publicitario
sku: 01-OFICI-0022
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Libretas
  description: ''
  image: 'https://reprodisseny.com/img/productos/libretas.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-publicitario/libretas
  sku: 01-OFICI-0022
  mpn: REF-01-OFICI-0022
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

## Libretas

## Libretas
