---
title: Imanes
metaTitle: Imanes | Repro Disseny
metaDescription: Imanes personalizadas con calidad profesional en Cataluña.
keywords:
  - imanes
searchTerms:
  - imanes
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: imanes
category: material-publicitario
sku: 01-OFICI-0012
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Imanes
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/publicitario-oficina/material-publicitario/imanes
  sku: 01-OFICI-0012
  mpn: REF-01-OFICI-0012
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

## Imanes

## Imanes
