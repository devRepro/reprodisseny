---
title: Identificador de maleta
metaTitle: Identificador de maleta | Repro Disseny
metaDescription: Identificador de maleta personalizadas con calidad profesional en Cataluña.
keywords:
  - identificador de maleta
searchTerms:
  - identificador de maleta
image: /img/productos/Identificador-maleta.webp
galleryImages: []
alt: alt descripció de la foto
slug: identificador-maleta
category: hoteles-restaurantes
sku: 01-HORE-0008
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Identificador de maleta
  description: ''
  image: 'https://reprodisseny.com/img/productos/Identificador-maleta.webp'
  url: >-
    https://reprodisseny.com/categorias/hoteles-restaurantes/identificador-maleta
  sku: 01-HORE-0008
  mpn: REF-01-HORE-0008
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

