---
title: Tabletents
metaTitle: Tabletents | Repro Disseny
metaDescription: Tabletents personalizadas con calidad profesional en Cataluña.
keywords:
  - tabletents
searchTerms:
  - tabletents
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: tabletents
category: hoteles-restaurantes
sku: 01-HORE-0009
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Tabletents
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/hoteles-restaurantes/tabletents'
  sku: 01-HORE-0009
  mpn: REF-01-HORE-0009
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

