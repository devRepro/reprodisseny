---
title: Colgador de puerta
metaTitle: Colgador de puerta | Repro Disseny
metaDescription: Colgador de puerta personalizadas con calidad profesional en Cataluña.
keywords:
  - colgador de puerta
searchTerms:
  - colgador de puerta
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: colgador-puerta
category: hoteles-restaurantes
sku: 01-HORE-0002
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Colgador de puerta
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/hoteles-restaurantes/colgador-puerta'
  sku: 01-HORE-0002
  mpn: REF-01-HORE-0002
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

