---
title: Nido abeja
metaTitle: Nido abeja | Repro Disseny
metaDescription: Nido abeja personalizadas con calidad profesional en Cataluña.
keywords:
  - nido abeja
searchTerms:
  - nido abeja
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: nido-abeja
category: material-flexible
sku: 01-GRFO-0013
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Nido abeja
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-flexible/nido-abeja
  sku: 01-GRFO-0013
  mpn: REF-01-GRFO-0013
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

