---
title: Dibon
metaTitle: Dibon | Repro Disseny
metaDescription: Dibon personalizadas con calidad profesional en Cataluña.
keywords:
  - dibon
searchTerms:
  - dibon
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: dibon
category: material-flexible
sku: 01-GRFO-0012
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Dibon
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/gran-formato/material-flexible/dibon'
  sku: 01-GRFO-0012
  mpn: REF-01-GRFO-0012
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

