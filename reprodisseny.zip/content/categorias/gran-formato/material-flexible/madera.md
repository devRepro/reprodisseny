---
title: Madera
metaTitle: Madera | Repro Disseny
metaDescription: Madera personalizadas con calidad profesional en Cataluña.
keywords:
  - madera
searchTerms:
  - madera
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: madera
category: material-flexible
sku: 01-GRFO-0018
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Madera
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/gran-formato/material-flexible/madera'
  sku: 01-GRFO-0018
  mpn: REF-01-GRFO-0018
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

