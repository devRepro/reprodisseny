---
title: Papel de pared
metaTitle: Papel de pared | Repro Disseny
metaDescription: Papel de pared personalizadas con calidad profesional en Cataluña.
keywords:
  - papel de pared
searchTerms:
  - papel de pared
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: papel-pared
category: material-flexible
sku: 01-GRFO-0003
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Papel de pared
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-flexible/papel-pared
  sku: 01-GRFO-0003
  mpn: REF-01-GRFO-0003
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

