---
title: Cartón compacto
metaTitle: Cartón compacto | Repro Disseny
metaDescription: Cartón compacto personalizadas con calidad profesional en Cataluña.
keywords:
  - cartón compacto
searchTerms:
  - cartón compacto
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: carton-compacto
category: material-flexible
sku: 01-GRFO-0015
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Cartón compacto
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-flexible/carton-compacto
  sku: 01-GRFO-0015
  mpn: REF-01-GRFO-0015
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

