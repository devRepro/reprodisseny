---
title: Cartón corrugado
metaTitle: Cartón corrugado | Repro Disseny
metaDescription: Cartón corrugado personalizadas con calidad profesional en Cataluña.
keywords:
  - cartón corrugado
searchTerms:
  - cartón corrugado
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: carton-corrugado
category: material-flexible
sku: 01-GRFO-0016
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Cartón corrugado
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-flexible/carton-corrugado
  sku: 01-GRFO-0016
  mpn: REF-01-GRFO-0016
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

