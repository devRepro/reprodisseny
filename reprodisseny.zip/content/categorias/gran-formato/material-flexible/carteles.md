---
title: Carteles
metaTitle: Carteles | Repro Disseny
metaDescription: Carteles personalizadas con calidad profesional en Cataluña.
keywords:
  - carteles
searchTerms:
  - carteles
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: carteles
category: material-flexible
sku: 01-GRFO-0002
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Carteles
  description: ''
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  url: 'https://reprodisseny.com/categorias/gran-formato/material-flexible/carteles'
  sku: 01-GRFO-0002
  mpn: REF-01-GRFO-0002
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---



