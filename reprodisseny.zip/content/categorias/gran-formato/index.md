---
alt: >-
  Soportes publicitarios de gran formato impresos para eventos y escaparates en
  Cataluña
brand: Repro Disseny
faqs: []
featured: true
formFields: []
galleryImages: []
image: Gran-formato.png
inStock: true
keywords:
  - impresión gran formato Barcelona
  - lonas publicitarias gran formato
  - carteles y pancartas eventos
  - vinilos decorativos oficinas
  - soportes publicitarios gran formato
metaDescription: >-
  Servicios de impresión en gran formato en Barcelona y Cataluña: lonas
  publicitarias, carteles, vinilos decorativos y más. Calidad premium y
  producción local.
metaTitle: Impresión en Gran Formato en Barcelona y Cataluña | Repro Disseny
nav: Gran Formato
order: 1
path: /categorias/gran-formato
priceCurrency: EUR
ratingValue: 4.8
reviewCount: 124
schema:
  '@type': CollectionPage
  name: Impresión en Gran Formato en Barcelona y Cataluña | Repro Disseny
  description: >-
    Servicios de impresión en gran formato en Barcelona y Cataluña: lonas
    publicitarias, carteles, vinilos decorativos y más. Calidad premium y
    producción local.
  image: 'https://reprodisseny.com/img/categorias/gran-formato.png'
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
schemaType: CollectionPage
searchTerms:
  - impresión gran formato Cataluña
  - impresión digital gran formato
  - cartelería gran formato Barcelona
slug: gran-formato
title: Impresión en Gran Formato en Barcelona y Cataluña | Repro Disseny
type: categoria
---

