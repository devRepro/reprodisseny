---
title: Tela poliester
metaTitle: Tela poliester | Repro Disseny
metaDescription: Tela poliester personalizadas con calidad profesional en Cataluña.
keywords:
  - tela poliester
searchTerms:
  - tela poliester
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: tela-poliester
category: material-rigido
sku: 01-GRFO-0005
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Tela poliester
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-rigido/tela-poliester
  sku: 01-GRFO-0005
  mpn: REF-01-GRFO-0005
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

