---
title: Vinilos a medida
metaTitle: Vinilos a medida | Repro Disseny
metaDescription: Vinilos a medida personalizadas con calidad profesional en Cataluña.
keywords:
  - vinilos a medida
searchTerms:
  - vinilos a medida
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: vinilos-medida
category: material-rigido
sku: 01-GRFO-0001
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Vinilos a medida
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-rigido/vinilos-medida
  sku: 01-GRFO-0001
  mpn: REF-01-GRFO-0001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---
## Vinilos a medida
