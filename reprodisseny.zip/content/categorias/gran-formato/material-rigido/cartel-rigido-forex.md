---
title: Cartel rígido forex
metaTitle: Cartel rígido forex
metaDescription: Cartel rígido forex personalizadas con calidad profesional en Cataluña.
keywords: []
searchTerms: []
image: /img/product/cartel-forex.webp
galleryImages: []
alt: Cartel rígido forex
slug: cartel-rigido-forex
category: material-rigido
sku: GF-MR-001
price: 19.99
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Cartel rígido forex
  description: ''
  image: 'https://reprodisseny.com/img/product/cartel-forex.webp'
  url: >-
    https://reprodisseny.com/categorias/gran-formato/material-rigido/cartel-rigido-forex
  sku: GF-MR-001
  mpn: REF-GF-MR-001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 19.99
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

