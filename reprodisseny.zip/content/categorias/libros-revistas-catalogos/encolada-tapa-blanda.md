---
title: Encuadernación  encolada tapa blanda
metaTitle: Encuadernación  encolada tapa blanda | Repro Disseny
metaDescription: >-
  Encuadernación  encolada tapa blanda personalizadas con calidad profesional en
  Cataluña.
keywords:
  - encuadernación  encolada tapa blanda
searchTerms:
  - encuadernación  encolada tapa blanda
image: /img/productos/Encolada-tapa-blanda.webp
galleryImages: []
alt: alt descripció de la foto
slug: encolada-tapa-blanda
category: libros-revistas-catalogos
sku: 01-PUBLI-0002
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Encuadernación  encolada tapa blanda
  description: ''
  image: 'https://reprodisseny.com/img/productos/Encolada-tapa-blanda.webp'
  url: >-
    https://reprodisseny.com/categorias/libros-revistas-catalogos/encolada-tapa-blanda
  sku: 01-PUBLI-0002
  mpn: REF-01-PUBLI-0002
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

