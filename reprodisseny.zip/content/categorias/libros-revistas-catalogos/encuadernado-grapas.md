---
title: Encuadernado grapas
metaTitle: Encuadernado grapas | Repro Disseny
metaDescription: Encuadernado grapas personalizadas con calidad profesional en Cataluña.
keywords:
  - encuadernado grapas
searchTerms:
  - encuadernado grapas
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: encuadernado-grapas
category: libros-revistas-catalogos
sku: 01-PUBLI-0001
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields:
  - label: Tipo Wire-o
    name: color
    type: select
    required: false
    options:
      - Blanco
      - Negro
      - Dourado
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Encuadernado grapas
  description: ''
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  url: >-
    https://reprodisseny.com/categorias/libros-revistas-catalogos/encuadernado-grapas
  sku: 01-PUBLI-0001
  mpn: REF-01-PUBLI-0001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

