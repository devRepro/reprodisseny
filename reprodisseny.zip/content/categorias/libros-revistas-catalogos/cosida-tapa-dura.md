---
title: Encuadernación  cosida tapa dura
metaTitle: Encuadernación  cosida tapa dura | Repro Disseny
metaDescription: >-
  Encuadernación  cosida tapa dura personalizadas con calidad profesional en
  Cataluña.
keywords:
  - encuadernación  cosida tapa dura
searchTerms:
  - encuadernación  cosida tapa dura
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: cosida-tapa-dura
category: libros-revistas-catalogos
sku: 01-PUBLI-0004
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Encuadernación  cosida tapa dura
  description: ''
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  url: >-
    https://reprodisseny.com/categorias/libros-revistas-catalogos/cosida-tapa-dura
  sku: 01-PUBLI-0004
  mpn: REF-01-PUBLI-0004
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

