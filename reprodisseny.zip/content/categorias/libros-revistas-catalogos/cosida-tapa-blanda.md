---
title: Encuadernación  cosida tapa blanda
metaTitle: Encuadernación  cosida tapa blanda | Repro Disseny
metaDescription: >-
  Encuadernación  cosida tapa blanda personalizadas con calidad profesional en
  Cataluña.
keywords:
  - encuadernación  cosida tapa blanda
searchTerms:
  - encuadernación  cosida tapa blanda
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: cosida-tapa-blanda
category: libros-revistas-catalogos
sku: 01-PUBLI-0003
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Encuadernación  cosida tapa blanda
  description: ''
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  url: >-
    https://reprodisseny.com/categorias/libros-revistas-catalogos/cosida-tapa-blanda
  sku: 01-PUBLI-0003
  mpn: REF-01-PUBLI-0003
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

