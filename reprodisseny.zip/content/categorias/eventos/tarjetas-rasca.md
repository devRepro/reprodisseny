---
title: Tarjetas rasca
metaTitle: Tarjetas rasca | Repro Disseny
metaDescription: Tarjetas rasca personalizadas con calidad profesional en Cataluña.
keywords:
  - tarjetas rasca
searchTerms:
  - tarjetas rasca
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: tarjetas-rasca
category: eventos
sku: 01-EVEN-0009
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Tarjetas rasca
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/tarjetas-rasca'
  sku: 01-EVEN-0009
  mpn: REF-01-EVEN-0009
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

