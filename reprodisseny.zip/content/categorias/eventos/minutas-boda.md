---
title: Minutas de boda
metaTitle: Minutas de boda | Repro Disseny
metaDescription: Minutas de boda personalizadas con calidad profesional en Cataluña.
keywords:
  - minutas de boda
searchTerms:
  - minutas de boda
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: minutas-boda
category: eventos
sku: 01-EVEN-0013
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Minutas de boda
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/minutas-boda'
  sku: 01-EVEN-0013
  mpn: REF-01-EVEN-0013
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

