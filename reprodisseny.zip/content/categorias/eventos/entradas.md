---
title: Entradas
metaTitle: Entradas | Repro Disseny
metaDescription: Entradas personalizadas con calidad profesional en Cataluña.
keywords:
  - entradas
searchTerms:
  - entradas
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: entradas
category: eventos
sku: 01-EVEN-0012
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Entradas
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/entradas'
  sku: 01-EVEN-0012
  mpn: REF-01-EVEN-0012
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

