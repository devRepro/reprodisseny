---
title: Figuras árbol de navidad
metaTitle: Figuras árbol de navidad | Repro Disseny
metaDescription: Figuras árbol de navidad personalizadas con calidad profesional en Cataluña.
keywords:
  - figuras árbol de navidad
searchTerms:
  - figuras árbol de navidad
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: figuras-arbol-navidad
category: eventos
sku: 01-EVEN-0018
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Figuras árbol de navidad
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/figuras-arbol-navidad'
  sku: 01-EVEN-0018
  mpn: REF-01-EVEN-0018
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

