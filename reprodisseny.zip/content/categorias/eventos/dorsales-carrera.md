---
title: Dorsales de carrera
metaTitle: Dorsales de carrera | Repro Disseny
metaDescription: Dorsales de carrera personalizadas con calidad profesional en Cataluña.
keywords:
  - dorsales de carrera
searchTerms:
  - dorsales de carrera
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: dorsales-carrera
category: eventos
sku: 01-EVEN-0006
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Dorsales de carrera
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/dorsales-carrera'
  sku: 01-EVEN-0006
  mpn: REF-01-EVEN-0006
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

