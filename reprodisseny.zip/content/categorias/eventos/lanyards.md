---
title: Lanyards
metaTitle: Lanyards | Repro Disseny
metaDescription: Lanyards personalizadas con calidad profesional en Cataluña.
keywords:
  - lanyards
searchTerms:
  - lanyards
image: /img/productos/Lanyard.webp
galleryImages: []
alt: alt descripció de la foto
slug: lanyards
category: eventos
sku: 01-EVEN-0004
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Lanyards
  description: ''
  image: 'https://reprodisseny.com/img/productos/Lanyard.webp'
  url: 'https://reprodisseny.com/categorias/eventos/lanyards'
  sku: 01-EVEN-0004
  mpn: REF-01-EVEN-0004
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

