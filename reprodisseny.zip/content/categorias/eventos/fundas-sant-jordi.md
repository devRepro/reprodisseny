---
title: Fundas Rosas Sant Jordi
metaTitle: Fundas Rosas Sant Jordi | Repro Disseny
metaDescription: Fundas Rosas Sant Jordi personalizadas con calidad profesional en Cataluña.
keywords:
  - fundas rosas sant jordi
searchTerms:
  - fundas rosas sant jordi
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: fundas-sant-jordi
category: eventos
sku: 01-EVEN-0001
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Fundas Rosas Sant Jordi
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/eventos/fundas-sant-jordi'
  sku: 01-EVEN-0001
  mpn: REF-01-EVEN-0001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

