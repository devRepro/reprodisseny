---
title: Roll Ups
metaTitle: Roll Ups | Repro Disseny
metaDescription: Roll Ups personalizadas con calidad profesional en Cataluña.
keywords:
  - roll ups
searchTerms:
  - roll ups
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: roll-ups
category: expositores
sku: 01-EXPO-0001
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Roll Ups
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/expositores/roll-ups'
  sku: 01-EXPO-0001
  mpn: REF-01-EXPO-0001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

