---
title: Expositores de suelo
metaTitle: Expositores de suelo | Repro Disseny
metaDescription: Expositores de suelo personalizadas con calidad profesional en Cataluña.
keywords:
  - expositores de suelo
searchTerms:
  - expositores de suelo
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: expositores-suelo
category: expositores
sku: 01-EXPO-0013
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Expositores de suelo
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/expositores/expositores-suelo'
  sku: 01-EXPO-0013
  mpn: REF-01-EXPO-0013
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

