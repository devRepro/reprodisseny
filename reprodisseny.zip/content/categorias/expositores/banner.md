---
title: Banner
metaTitle: Banner | Repro Disseny
metaDescription: Banner personalizadas con calidad profesional en Cataluña.
keywords:
  - banner
searchTerms:
  - banner
image: /img/productos/Banners.webp
galleryImages: []
alt: alt descripció de la foto
slug: banner
category: expositores
sku: 01-EXPO-0002
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Banner
  description: ''
  image: 'https://reprodisseny.com/img/productos/Banners.webp'
  url: 'https://reprodisseny.com/categorias/expositores/banner'
  sku: 01-EXPO-0002
  mpn: REF-01-EXPO-0002
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

