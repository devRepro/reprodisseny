---
title: Expositores de mesa
metaTitle: Expositores de mesa | Repro Disseny
metaDescription: Expositores de mesa personalizadas con calidad profesional en Cataluña.
keywords:
  - expositores de mesa
searchTerms:
  - expositores de mesa
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: expositores-mesa
category: expositores
sku: 01-EXPO-0012
price: 0
priceCurrency: EUR
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
type: producto
schema:
  '@type': Product
  name: Expositores de mesa
  description: ''
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  url: 'https://reprodisseny.com/categorias/expositores/expositores-mesa'
  sku: 01-EXPO-0012
  mpn: REF-01-EXPO-0012
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
---

