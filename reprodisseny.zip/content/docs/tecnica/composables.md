---
title: "Composables"
description: "Listado de composables personalizados y su función"
---

# 🧩 Composables

- `useCategoriasNav()`: carga categorías y productos para el megamenú
- `useSearch()`: gestiona el estado del buscador Command
