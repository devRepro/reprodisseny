---
title: "Layouts en Nuxt"
description: "Organización de layouts globales y por sección"
---

# 📐 Layouts

- `default.vue`: layout principal con menú, buscador y footer
- `docs.vue`: layout limpio para la documentación
