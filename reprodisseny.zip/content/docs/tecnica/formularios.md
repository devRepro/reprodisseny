---
title: "Formularios Dinámicos"
description: "Estructura y validación de formularios generados desde Markdown"
---

# 📝 Formularios Dinámicos

Cada producto puede tener un formulario generado automáticamente desde el campo `formFields` del `.md`.

- Validación con `vee-validate` + `zod`
- Estilos con `shadcn-vue`
