---
title: "Buscador"
description: "Implementación del buscador con Shadcn y @nuxt/content"
---

# 🔍 Buscador

El buscador usa el componente `Command` de shadcn-vue, y filtra datos desde `@nuxt/content` con `queryCollection()` agrupando por categoría y producto.
