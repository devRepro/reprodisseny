<template>
    <span>Novedades</span>
</template>