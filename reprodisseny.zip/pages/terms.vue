<script setup lang="ts">
</script>

<template>

<h1>Términos y Condiciones de Uso</h1>

<h2>1. Introducción</h2>
<p>1.1. Bienvenido a <strong>REPRO DISSENY</strong>. Al acceder y utilizar este sitio web (<code>www.reprodisseny.com</code> y subdominios asociados), aceptas estos Términos y Condiciones de Uso y nuestra Política de Privacidad. Si no estás de acuerdo, te pedimos que no utilices el sitio.</p>
<p>1.2. Este sitio es propiedad de <strong>REPRO DISSENY, S.L.</strong>, con domicilio en Calle Juan de Mena, 19, 08035 Barcelona, CIF: B-64555105. Inscrita en el Registro Mercantil de Barcelona, Tomo 39661, Folio 61, Hoja B-349885. Contacto: <a href="mailto:repro@reprodisseny.com">repro@reprodisseny.com</a></p>
<p>1.3. Te recomendamos leer y conservar una copia de estos términos, que estarán siempre disponibles en el sitio web.</p>
<p>1.4. Para usar el sitio, debes cumplir estos requisitos:</p>
<ul>
  <li>Tener al menos 18 años, o 16 con consentimiento paterno/tutor.</li>
  <li>Tener capacidad legal para aceptar un contrato vinculante.</li>
  <li>Residir en España.</li>
</ul>
<p>El usuario garantiza que la información que proporcione será veraz y actualizada.</p>

<h2>2. Objeto</h2>
<p>2.1. Navegar por el sitio implica la aceptación total de estas condiciones, sin necesidad de firma física.</p>
<p>2.2. El usuario, ya sea persona física o jurídica, acepta usar el sitio bajo su responsabilidad, incluyendo el uso de la información, servicios y contenidos ofrecidos por REPRO DISSENY.</p>

<h2>3. Normas de Uso</h2>

<h3>3.1 Acceso</h3>
<ul>
  <li>El usuario necesita conexión a internet y un dispositivo adecuado para acceder.</li>
  <li>Algunos contenidos pueden requerir descargas. El usuario asume la responsabilidad de instalar lo necesario.</li>
</ul>

<h3>3.2 Uso correcto</h3>
<ul>
  <li>El sitio debe utilizarse conforme a la ley, la moral y el orden público.</li>
  <li>Queda prohibido dañar el sitio, introducir virus o alterar sistemas.</li>
  <li>REPRO DISSENY puede denegar el acceso a quien incumpla estas condiciones.</li>
</ul>

<h3>3.3 Limitación de responsabilidad</h3>
<p>REPRO DISSENY no será responsable de:</p>
<ul>
  <li>Problemas de conexión o velocidad del usuario.</li>
  <li>Interrupciones del sistema por causas externas.</li>
  <li>Contenidos introducidos por terceros ajenos a la empresa.</li>
</ul>

<h2>4. Enlaces y contenido externo</h2>
<p>4.1. No nos responsabilizamos del contenido ni legalidad de páginas externas enlazadas desde nuestro sitio.</p>
<p>4.2. Aunque tomamos medidas de seguridad, navegar por internet conlleva riesgos. No somos responsables de posibles daños derivados de la navegación.</p>

<h2>5. Vigencia y cambios</h2>
<p>5.1. REPRO DISSENY puede modificar estos términos en cualquier momento, sin previo aviso.</p>
<p>5.2. Las nuevas condiciones serán válidas desde su publicación en el sitio.</p>

<h2>6. Propiedad intelectual e industrial</h2>
<p>6.1. Todos los contenidos del sitio son propiedad de REPRO DISSENY o se usan con permiso, y están protegidos por la legislación vigente.</p>
<p>6.2. Está prohibida su reproducción, distribución o modificación sin consentimiento expreso.</p>

<h2>7. Legislación y jurisdicción</h2>
<p>7.1. REPRO DISSENY podrá ejercer acciones legales por el uso indebido del sitio o incumplimiento de estos términos.</p>
<p>7.2. Las disputas se resolverán conforme a la legislación española, en los tribunales de <strong>Barcelona</strong>.</p>

<h2>8. Protección de datos</h2>
<p>8.1. De acuerdo con el <strong>Reglamento (UE) 2016/679 (RGPD)</strong>, los datos personales recabados serán tratados por REPRO DISSENY para gestionar la relación con el usuario y realizar labores comerciales y estadísticas.</p>
<p>8.2. La base legal es el interés legítimo o el consentimiento del usuario (por ejemplo, para cookies). Los datos se conservarán mientras exista ese consentimiento, salvo obligación legal de conservación.</p>
<p>8.3. Puedes ejercer tus derechos de:</p>
<ul>
  <li>Acceso</li>
  <li>Rectificación</li>
  <li>Limitación</li>
  <li>Supresión</li>
  <li>Portabilidad</li>
  <li>Oposición</li>
</ul>
<p>También puedes retirar tu consentimiento en cualquier momento o presentar una reclamación ante la autoridad de control.</p>
<p>8.4. Adoptamos medidas técnicas y organizativas para garantizar la seguridad de los datos. Si introduces datos en formularios de terceros, ellos serán responsables de su tratamiento.</p>

<p><em>Fecha de última actualización: Barcelona, 09 de mayo de 2007.</em></p>

</template>