<template>
  <div class="min-h-screen bg-gray-100 p-6">
    <h1 class="text-2xl font-bold mb-4">Contacto</h1>

  </div>
</template>

<script setup>
definePageMeta({
  layout: 'default'
})

</script>
