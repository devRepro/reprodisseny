<script setup lang="ts">
import logoMobile from '@/assets/img/logos/LogoMobile.png'
</script>
<template>
  <div class="w-36">
    <img :src="logoMobile" alt="Repro Disseny Logo Móvil" />
  </div>
</template>
