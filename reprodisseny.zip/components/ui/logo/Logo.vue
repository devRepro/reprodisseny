<template>
  <div class="overflow-hidden" v-bind="$attrs">
    <img
      src="@/assets/img/logos/logo.svg"
      alt="Logo Repro Disseny, imprenta digital, impresión óffset y gran formato"
      class="block h-full w-auto" />
  </div>
</template>

<script setup lang="ts">
// No script logic needed usually for a simple logo
// Use defineOptions({ inheritAttrs: false }) if you apply $attrs manually deeper
</script>