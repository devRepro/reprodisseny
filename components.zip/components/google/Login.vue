<template>
  <div>
    <h2>Conectar cuenta de Google Business</h2>
    <p>Necesitamos tu permiso para gestionar las reseñas.</p>

    <a href="/api/gbp/oauth/login"> Conectar con Google </a>
  </div>
</template>
