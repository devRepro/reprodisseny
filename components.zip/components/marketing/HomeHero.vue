<script setup lang="ts">
import AppButton from "@/components/shared/button/AppButton.vue";
</script>

<template>
  <section class="overflow-hidden bg-sky-100">
    <div class="container-wide py-6 md:py-10 lg:py-14">
      <div
        class="grid items-start gap-6 md:gap-8 lg:grid-cols-[minmax(0,1.15fr)_minmax(280px,0.85fr)] lg:items-center"
      >
        <div class="max-w-3xl">
          <!-- Badge compacto para móvil/tablet -->
          <div
            class="inline-flex items-center gap-3 rounded-full bg-white/90 px-3 py-2 shadow-sm ring-1 ring-black/5 backdrop-blur"
          >
            <div
              class="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full bg-white"
            >
              <img
                src="/img/logo/reprodisseny_1983.svg"
                alt="Reprodisseny"
                class="h-full w-full object-cover"
              />
            </div>

            <div class="min-w-0">
              <p class="truncate text-sm font-semibold leading-none text-slate-900">
                Reprodisseny
              </p>
              <p class="mt-1 text-xs leading-none text-slate-600">Desde 1983</p>
            </div>
          </div>

          <h1
            class="mt-4 max-w-[14ch] text-3xl font-extrabold leading-[1.05] text-slate-900 sm:text-4xl lg:mt-6 lg:text-5xl"
          >
            Tu imprenta digital de confianza en Barcelona
          </h1>

          <p
            class="mt-4 max-w-2xl text-base leading-7 text-slate-700 sm:text-lg sm:leading-8"
          >
            Convertimos tus necesidades en materiales de comunicación corporativa,
            comercial y marketing. Producimos tus proyectos profesionalmente,
            acompañándote, con calidad y rapidez.
          </p>

          <div class="mt-6 flex flex-col gap-3 sm:mt-8 sm:flex-row">
            <AppButton
              to="/contacto"
              variant="primary"
              size="lg"
              class="w-full sm:w-auto"
            >
              Contacta con un experto
            </AppButton>
          </div>
        </div>

        <!-- Pieza visual solo en desktop -->
        <div class="hidden lg:flex lg:justify-end">
          <div
            class="flex h-44 w-44 items-center justify-center overflow-hidden rounded-full bg-white shadow-lg ring-1 ring-black/5"
          >
            <img
              src="/img/logo/reprodisseny_1983.svg"
              alt="Reprodisseny desde 1983"
              class="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>

      <div class="mt-6 md:mt-8 lg:mt-10">
        <slot />
      </div>
    </div>
  </section>
</template>
