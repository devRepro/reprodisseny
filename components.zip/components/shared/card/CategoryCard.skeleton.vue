<!-- ===============================
components/shared/card/CategoryCard.skeleton.vue (optional)
================================== -->
<template>
  <div class="h-full animate-pulse overflow-hidden rounded-2xl border bg-card/60">
    <div class="aspect-[4/3] md:aspect-square bg-muted"></div>
    <div class="space-y-3 p-4">
      <div class="h-4 w-2/3 rounded bg-muted"></div>
      <div class="h-3 w-full rounded bg-muted"></div>
      <div class="h-3 w-5/6 rounded bg-muted"></div>
      <div class="h-8 w-32 rounded bg-muted"></div>
    </div>
  </div>
</template>
</template>
