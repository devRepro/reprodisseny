<template>
  <img
    src="/img/logo/logo.svg"
    alt="Reprodisseny"
    class="h-8 w-auto block"
    decoding="async"
    draggable="false"
  />
</template>

<script setup lang="ts">
// nada más
</script>
