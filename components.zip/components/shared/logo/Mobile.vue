<script setup lang="ts">
const src = "/img/logo/logo-mobile.png"; // en /publicgos/LogoMobile.png";
</script>
<template>
  <div class="w-36">
    <img :src="logoMobile" alt="Repro Disseny Logo Móvil" />
  </div>
</template>
