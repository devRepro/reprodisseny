<template>
  <div class="flex items-center justify-center w-full h-full" role="status">
    <svg
      class="animate-spin h-8 w-8 text-gray-200 dark:text-gray-600 fill-[hsl(var(--color-primary))]"
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 100 101"
      fill="none"
    >
      <path
        d="M100 50.5C100 78.3 77.6 100.7 50 100.7 22.4 100.7 0 78.3 0 50.5 0 22.7 22.4.3 50 .3c27.6 0 50 22.4 50 50.2z"
        fill="currentColor"
      />
      <path
        d="M93.9 39.1c2.2-.6 3.5-2.9 2.7-5.1a49.6 49.6 0 0 0-9.5-16.3A50.1 50.1 0 0 0 50 0v10c11.4 0 21.9 4.4 29.9 12.4a39.7 39.7 0 0 1 7.5 12.7c.7 2.2 2.9 3.5 5.1 2.7z"
        fill="currentFill"
      />
    </svg>
    <span class="sr-only">Cargando...</span>
  </div>
</template>
