---
title: "Cart\xF3n corrugado"
slug: carton-corrugado
category: gran-formato
type: producto
description: "descripci\xF3n gen\xE9rica de mi producto para probar"
image: img/productos/mockupProduct.webp
alt: "alt descripci\xF3 de la foto"
metatitle: .nan
tags: []
navigation: true
sku: 01-GRFO-0016
price: 0.0
priceCurrency: EUR
inStock: true
brand: Reprodisseny
schema:
  '@type': Product
  name: "Cart\xF3n corrugado personalizados"
  description: "descripci\xF3n gen\xE9rica de mi producto para probar"
  image: img/productos/mockupProduct.webp
  sku: 01-GRFO-0016
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0.0
    priceCurrency: EUR
    availability: https://schema.org/InStock
metadescription: "descripci\xF3n gen\xE9rica de mi producto para probar"
keywords:
- "cart\xF3n corrugado"
- "impresi\xF3n cart\xF3n corrugado"
- "cart\xF3n corrugado personalizado"
- "cart\xF3n corrugado para negocios"
- "cart\xF3n corrugado Reprodisseny"
---

## Cartón corrugado
