---
title: " Impresi\xF3n en gran formato para publicidad y eventos | Repro Disseny"
description: "Roll-ups, lonas, paneles r\xEDgidos, foam y m\xE1s. Impresi\xF3n en\
  \ gran formato ideal para ferias, campa\xF1as y retail. Calidad premium y producci\xF3\
  n local en Catalu\xF1a."
keywords:
- "Impresi\xF3n en gran formato en Barcelona\u200B\nLonas publicitarias de gran tama\xF1\
  o\u200B\nCarteles y pancartas para eventos\u200B\nVinilos decorativos para oficinas\u200B\
  \nSoportes publicitarios de gran formato"
image: Gran-formato.png
alt: "Soportes publicitarios de gran formato impresos para eventos y escaparates en\
  \ Catalu\xF1a"
nav: Gran Formato
slug: gran-formato
navigation: true
type: categoria
metatitle: " Impresi\xF3n en gran formato para publicidad y eventos | Repro Disseny\
  \ | Reprodisseny"
metadescription: "Roll-ups, lonas, paneles r\xEDgidos, foam y m\xE1s. Impresi\xF3\
  n en gran formato ideal para ferias, campa\xF1as y retail. Calidad premium y producci\xF3\
  n local en Catalu\xF1a."
---

# ' Impresión en gran formato para publicidad y eventos | Repro Disseny'
