---
title: Flyers
slug: flyers
category: publicitario-oficina
type: producto
description: "descripci\xF3n gen\xE9rica de mi producto para probar"
image: /img/productos/Flyer.webp
alt: "alt descripci\xF3 de la foto"
metatitle: .nan
tags: []
navigation: true
sku: 01-OFICI-0002
price: 0.0
priceCurrency: EUR
inStock: true
brand: Reprodisseny
schema:
  '@type': Product
  name: Flyers personalizados
  description: "descripci\xF3n gen\xE9rica de mi producto para probar"
  image: /img/productos/Flyer.webp
  sku: 01-OFICI-0002
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0.0
    priceCurrency: EUR
    availability: https://schema.org/InStock
formFields:
- label: "Tama\xF1o"
  name: tamano
  type: select
  required: true
  options:
  - A5
  - A4
  - A3
- label: Tipo de papel
  name: papel
  type: select
  required: true
  options:
  - "Couch\xE9"
  - Reciclado
  - Estucado
- label: Acabado
  name: acabado
  type: select
  required: false
  options:
  - Brillo
  - Mate
metadescription: "descripci\xF3n gen\xE9rica de mi producto para probar"
keywords:
- flyers
- "impresi\xF3n flyers"
- flyers personalizado
- flyers para negocios
- flyers Reprodisseny
---

## Flyers
