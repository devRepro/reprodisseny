---
title: "D\xEDptico tarjeta habitaci\xF3n"
slug: diptico-habitacion
category: hoteles-restaurantes
type: producto
description: "descripci\xF3n gen\xE9rica de mi producto para probar"
image: img/productos/mockupProduct.webp
alt: "alt descripci\xF3 de la foto"
metatitle: .nan
tags: []
navigation: true
sku: 01-HORE-0001
price: 0.0
priceCurrency: EUR
inStock: true
brand: Reprodisseny
schema:
  '@type': Product
  name: "D\xEDptico tarjeta habitaci\xF3n personalizados"
  description: "descripci\xF3n gen\xE9rica de mi producto para probar"
  image: img/productos/mockupProduct.webp
  sku: 01-HORE-0001
  brand:
    '@type': Organization
    name: Reprodisseny
  offers:
    '@type': Offer
    price: 0.0
    priceCurrency: EUR
    availability: https://schema.org/InStock
metadescription: "descripci\xF3n gen\xE9rica de mi producto para probar"
keywords:
- "d\xEDptico tarjeta habitaci\xF3n"
- "impresi\xF3n d\xEDptico tarjeta habitaci\xF3n"
- "d\xEDptico tarjeta habitaci\xF3n personalizado"
- "d\xEDptico tarjeta habitaci\xF3n para negocios"
- "d\xEDptico tarjeta habitaci\xF3n Reprodisseny"
---

## Díptico tarjeta habitación
