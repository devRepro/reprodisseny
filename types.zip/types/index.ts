export * from './seo'
export * from './catalog'
export * from './nuxt'
export * from './navigation'  // 👈 nuevo
export * from './content'     // 👈 nuevo
export * from './product'