// @types/categorias.ts
export interface CategoriaFrontmatter {
    title: string
    slug?: string        // si no viene, se infiere del path
    parent?: string      // slug del padre (opcional si inferimos del path)
    nav?: string         // etiqueta de menú
    order?: number
    hidden?: boolean
    image?: string
    description?: string
    featured?: boolean
  }
  
  export interface CategoriaNode {
    id: string           // slug absoluto (p.e. "impresion/digital")
    title: string
    nav: string | null
    order: number
    path: string         // ruta de página pública (/categorias/impresion/digital)
    hidden: boolean
    image?: string
    description?: string
    featured?: boolean
    parentId: string | null
    children: CategoriaNode[]
  }
  
  export interface CategoriaPayload {
    nodes: CategoriaNode[]
    indexById: Record<string, CategoriaNode>
    tree: CategoriaNode[]                // solo raíces (parentId === null)
  }
  
  export interface CategoriaBySlugPayload {
    categoria: CategoriaNode | null
    breadcrumbs: CategoriaNode[]
    children: CategoriaNode[]
  }
  
  export interface CategoriasHomePayload {
    items: CategoriaNode[]
  }
  