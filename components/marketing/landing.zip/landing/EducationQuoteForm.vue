<script setup lang="ts">
import { computed, reactive, ref } from "vue";
import { useRoute } from "#imports";
import { Loader2 } from "lucide-vue-next";
import RequestSuccessState from "@/components/marketing/quote/RequestSuccessState.vue";
import { usePriceRequests } from "@/composables/usePriceRequests";

type Locale = "es" | "ca";

type QuoteForm = {
  website: string;
  name: string;
  center: string;
  email: string;
  phone: string;
  message: string;
  privacy: boolean;
};

const props = withDefaults(
  defineProps<{
    locale?: Locale;
    productName?: string;
    productSlug?: string;
    categorySlug?: string;
  }>(),
  {
    locale: "es",
    productName: "Material gráfico para centros educativos",
    productSlug: "centros-educativos",
    categorySlug: "publicaciones",
  }
);

const copy = computed(() => {
  if (props.locale === "ca") {
    return {
      successTitle: "Sol·licitud enviada correctament",
      name: "Nom *",
      center: "Centre",
      email: "Email *",
      phone: "Telèfon *",
      message: "Què necessites? *",
      required: "Els camps marcats amb * són obligatoris.",
      privacyStart: "He llegit i accepto la",
      privacyLink: "política de privacitat",
      submit: "Parlar amb un expert",
      submitting: "Enviant...",
      fallback: "Sol·licitud de pressupost per a centres educatius.",
      errors: {
        name: "Indica el teu nom.",
        email: "Introdueix un email vàlid.",
        phone: "Introdueix un telèfon vàlid.",
        message: "Explica breument què necessites.",
        privacy: "Has d’acceptar la política de privacitat.",
        generic:
          "No hem pogut enviar la sol·licitud. Torna-ho a intentar o truca’ns al +34 932 749 890.",
      },
    };
  }

  return {
    successTitle: "Solicitud enviada correctamente",
    name: "Nombre *",
    center: "Centro",
    email: "Email *",
    phone: "Teléfono *",
    message: "¿Qué necesitas? *",
    required: "Los campos marcados con * son obligatorios.",
    privacyStart: "He leído y acepto la",
    privacyLink: "política de privacidad",
    submit: "Habla con un experto",
    submitting: "Enviando...",
    fallback: "Solicitud de presupuesto para centros educativos.",
    errors: {
      name: "Indica tu nombre.",
      email: "Introduce un email válido.",
      phone: "Introduce un teléfono válido.",
      message: "Explica brevemente qué necesitas.",
      privacy: "Debes aceptar la política de privacidad.",
      generic:
        "No hemos podido enviar la solicitud. Inténtalo de nuevo o llámanos al +34 932 749 890.",
    },
  };
});

const route = useRoute();
const { sendPriceRequest, isLoading, error } = usePriceRequests();

const success = ref(false);
const validationError = ref("");
const submittedReference = ref<string | null>(null);

const form = reactive<QuoteForm>({
  website: "",
  name: "",
  center: "",
  email: "",
  phone: "",
  message: "",
  privacy: false,
});

const sourceUrl = computed(() => {
  const value = import.meta.client ? window.location.href : route.fullPath || "/";
  return String(value).slice(0, 300);
});

const utm = computed(() => {
  const out: Record<string, string> = {};

  for (const [key, value] of Object.entries(route.query || {})) {
    if (!key.toLowerCase().startsWith("utm_")) continue;
    out[key] = Array.isArray(value) ? String(value[0] ?? "") : String(value ?? "");
  }

  return Object.keys(out).length ? out : null;
});

const errorMessage = computed(() => {
  if (validationError.value) return validationError.value;
  if (!error.value) return "";
  return typeof error.value === "string" ? error.value : copy.value.errors.generic;
});

function resetForm() {
  form.website = "";
  form.name = "";
  form.center = "";
  form.email = "";
  form.phone = "";
  form.message = "";
  form.privacy = false;
  validationError.value = "";
  submittedReference.value = null;
}

function handleResetSuccessState() {
  success.value = false;
  resetForm();
}

function isValidEmail(value: string) {
  return /^\S+@\S+\.\S+$/.test(value.trim());
}

function pushLeadEvent(transactionId?: string | number | null) {
  if (!import.meta.client) return;

  const win = window as Window & { dataLayer?: Record<string, unknown>[] };
  win.dataLayer = win.dataLayer || [];

  win.dataLayer.push({
    event: "generate_lead",
    form_name:
      props.locale === "ca"
        ? "landing_ensenyament"
        : "landing_centros_educativos",
    lead_type: "quote_request",
    page_path: window.location.pathname,
    category_slug: props.categorySlug,
    product_slug: props.productSlug,
    product_name: props.productName,
    transaction_id: transactionId ? String(transactionId) : undefined,
  });
}

async function onSubmit() {
  validationError.value = "";
  error.value = null;

  if (form.website.trim()) {
    success.value = true;
    return;
  }

  if (!form.name.trim()) {
    validationError.value = copy.value.errors.name;
    return;
  }

  if (!isValidEmail(form.email)) {
    validationError.value = copy.value.errors.email;
    return;
  }

  if (!form.phone.trim() || form.phone.trim().length < 9) {
    validationError.value = copy.value.errors.phone;
    return;
  }

  if (!form.message.trim()) {
    validationError.value = copy.value.errors.message;
    return;
  }

  if (!form.privacy) {
    validationError.value = copy.value.errors.privacy;
    return;
  }

  const fallbackMessage = [
    copy.value.fallback,
    `Centro: ${form.center || "sin indicar"}.`,
    `Necesidad: ${form.message || "sin indicar"}.`,
  ].join(" ");

  const response = await sendPriceRequest(
    {
      website: null,
      name: form.name.trim(),
      email: form.email.trim(),
      phone: form.phone.trim(),
      company: form.center.trim() || null,
      message: form.message.trim() || fallbackMessage,
      categorySlug: props.categorySlug,
      product: {
        name: props.productName,
        slug: props.productSlug,
        sku: null,
        url: sourceUrl.value,
      },
      extras: {
        landing: props.locale === "ca" ? "ensenyament" : "centros-educativos",
        locale: props.locale,
        center: form.center.trim() || null,
      },
      consent: true,
      sourceUrl: sourceUrl.value,
      utm: utm.value,
      initialStatus: "Nova",
    },
    { file: null, fileKind: "design" }
  );

  const result = response as {
    ok?: boolean;
    duplicated?: boolean;
    itemId?: string | number | null;
    requestKey?: string | null;
    reference?: string | null;
    requestId?: string | null;
    id?: string | number | null;
  } | null;

  if (!error.value) {
    const transactionId =
      result?.reference ||
      result?.requestId ||
      result?.id ||
      result?.itemId ||
      result?.requestKey ||
      null;

    submittedReference.value = transactionId ? String(transactionId) : null;

    if (!result?.duplicated) {
      pushLeadEvent(transactionId);
    }

    success.value = true;
    resetForm();
  }
}
</script>

<template>
  <div class="mx-auto w-full max-w-[560px]">
    <RequestSuccessState
      v-if="success"
      :product-name="props.productName"
      :title="copy.successTitle"
      primary-to="/"
      @reset="handleResetSuccessState"
    />

    <form
      v-else
      class="rounded-3xl border border-border/70 bg-white p-5 shadow-[0_24px_70px_-42px_rgba(0,0,0,.5)] md:p-8"
      novalidate
      @submit.prevent="onSubmit"
    >
      <div
        v-if="errorMessage"
        class="mb-4 rounded-lg border border-destructive/20 bg-destructive/10 px-3 py-2 text-sm font-medium text-destructive"
      >
        {{ errorMessage }}
      </div>

      <input
        v-model="form.website"
        type="text"
        name="website"
        tabindex="-1"
        autocomplete="off"
        class="hidden"
        aria-hidden="true"
      />

      <div class="grid gap-4">
        <label class="block">
          <span class="mb-1.5 block text-sm font-medium text-foreground">
            {{ copy.name }}
          </span>
          <input
            v-model="form.name"
            name="name"
            type="text"
            autocomplete="name"
            required
            class="h-11 w-full rounded-xl border border-border bg-white px-3 text-[15px] outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </label>

        <label class="block">
          <span class="mb-1.5 block text-sm font-medium text-foreground">
            {{ copy.center }}
          </span>
          <input
            v-model="form.center"
            name="center"
            type="text"
            autocomplete="organization"
            class="h-11 w-full rounded-xl border border-border bg-white px-3 text-[15px] outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </label>

        <div class="grid gap-4 md:grid-cols-2">
          <label class="block">
            <span class="mb-1.5 block text-sm font-medium text-foreground">
              {{ copy.email }}
            </span>
            <input
              v-model="form.email"
              name="email"
              type="email"
              autocomplete="email"
              required
              class="h-11 w-full rounded-xl border border-border bg-white px-3 text-[15px] outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
            />
          </label>

          <label class="block">
            <span class="mb-1.5 block text-sm font-medium text-foreground">
              {{ copy.phone }}
            </span>
            <input
              v-model="form.phone"
              name="phone"
              type="tel"
              inputmode="tel"
              autocomplete="tel"
              required
              class="h-11 w-full rounded-xl border border-border bg-white px-3 text-[15px] outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
            />
          </label>
        </div>

        <label class="block">
          <span class="mb-1.5 block text-sm font-medium text-foreground">
            {{ copy.message }}
          </span>
          <textarea
            v-model="form.message"
            name="message"
            rows="5"
            required
            class="w-full resize-y rounded-xl border border-border bg-white px-3 py-2.5 text-[15px] outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15"
          />
        </label>
      </div>

      <p class="mt-4 text-xs leading-5 text-muted-foreground">
        {{ copy.required }}
      </p>

      <label class="mt-3 flex items-start gap-2 text-xs leading-5 text-foreground/75">
        <input
          v-model="form.privacy"
          type="checkbox"
          required
          class="mt-1 h-4 w-4 shrink-0 rounded border-border text-primary focus:ring-primary/20"
        />
        <span>
          {{ copy.privacyStart }}
          <NuxtLink
            to="/politica-privacidad"
            target="_blank"
            class="font-semibold text-primary hover:underline"
          >
            {{ copy.privacyLink }}
          </NuxtLink>.
        </span>
      </label>

      <button
        type="submit"
        :disabled="isLoading"
        class="mt-6 inline-flex h-12 w-full items-center justify-center rounded-xl bg-primary px-4 text-sm font-semibold uppercase tracking-[0.12em] text-primary-foreground shadow-sm transition hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-70"
      >
        <Loader2 v-if="isLoading" class="mr-2 h-4 w-4 animate-spin" />
        {{ isLoading ? copy.submitting : copy.submit }}
      </button>
    </form>
  </div>
</template>