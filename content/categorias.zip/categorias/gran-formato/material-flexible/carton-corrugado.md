---
metaTitle: Cartón corrugado | Repro Disseny
metaDescription: Cartón corrugado personalizadas con calidad profesional en Cataluña.
keywords:
  - cartón corrugado
searchTerms:
  - cartón corrugado
image: /img/productos/mockupProduct.web
galleryImages: []
alt: alt descripció de la foto
slug: carton-corrugado
category: material-flexible
sku: 01-GRFO-0016
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Cartón corrugado
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Cartón corrugado
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.web'
  sku: 01-GRFO-0016
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Cartón corrugado
---

## Cartón corrugado

## Cartón corrugado
