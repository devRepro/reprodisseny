---
metaTitle: Papel de pared | Repro Disseny
metaDescription: Papel de pared personalizadas con calidad profesional en Cataluña.
keywords:
  - papel de pared
searchTerms:
  - papel de pared
image: /img/productos/mockupProduct.web
galleryImages: []
alt: alt descripció de la foto
slug: papel-pared
category: material-flexible
sku: 01-GRFO-0003
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Papel de pared
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Papel de pared
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.web'
  sku: 01-GRFO-0003
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Papel de pared
---

## Papel de pared

## Papel de pared
