---
metaTitle: Dispa | Repro Disseny
metaDescription: Dispa personalizadas con calidad profesional en Cataluña.
keywords:
  - dispa
searchTerms:
  - dispa
image: /img/productos/mockupProduct.web
galleryImages: []
alt: alt descripció de la foto
slug: dispa
category: material-flexible
sku: 01-GRFO-0014
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Dispa
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Dispa
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.web'
  sku: 01-GRFO-0014
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Dispa
---

## Dispa

## Dispa
