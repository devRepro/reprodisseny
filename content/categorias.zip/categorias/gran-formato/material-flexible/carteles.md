---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: carteles
category: gran-formato
sku: 01-GRFO-0002
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Carteles
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Carteles
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  sku: 01-GRFO-0002
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Carteles
---
## Carteles
