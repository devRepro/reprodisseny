---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/Flyer.webp
galleryImages: []
alt: alt descripció de la foto
slug: flyers
category: publicitario-oficina
sku: 01-OFICI-0002
price: 0
brand: Reprodisseny
inStock: true
formFields:
  - label: Tamaño
    name: tamano
    type: select
    required: true
    options:
      - A5
      - A4
      - A3
  - label: Tipo de papel
    name: papel
    type: select
    required: true
    options:
      - Couché
      - Reciclado
      - Estucado
  - label: Acabado
    name: acabado
    type: select
    required: false
    options:
      - Brillo
      - Mate
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Flyers
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Flyers
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/Flyer.webp'
  sku: 01-OFICI-0002
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Flyers
---
## Flyers
