---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/Folletos-plegados.webp
galleryImages: []
alt: alt descripció de la foto
slug: folletos-plegados
category: publicitario-oficina
sku: 01-OFICI-0006
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Folletos plegados
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Folletos plegados
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/Folletos-plegados.webp'
  sku: 01-OFICI-0006
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Folletos plegados
---
## Folletos plegados
