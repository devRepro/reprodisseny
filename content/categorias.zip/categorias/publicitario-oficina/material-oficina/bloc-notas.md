---
metaTitle: Bloc de notas | Repro Disseny
metaDescription: Bloc de notas personalizadas con calidad profesional en Cataluña.
keywords:
  - bloc de notas
searchTerms:
  - bloc de notas
image: /img/productos/bloc-de-notas.webp
galleryImages: []
alt: alt descripció de la foto
slug: bloc-notas
category: material-oficina
sku: 01-OFICI-0021
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Bloc de notas
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Bloc de notas
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/bloc-de-notas.webp'
  sku: 01-OFICI-0021
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Bloc de notas
---

## Bloc de notas

## Bloc de notas
