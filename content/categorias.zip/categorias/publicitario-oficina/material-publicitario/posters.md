---
metaTitle: Posters | Repro Disseny
metaDescription: Posters personalizadas con calidad profesional en Cataluña.
keywords:
  - posters
searchTerms:
  - posters
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: posters
category: material-publicidad
sku: 01-OFICI-0004
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Posters
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Posters
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  sku: 01-OFICI-0004
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Posters
---

## Posters

## Posters
