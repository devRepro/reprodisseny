---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/mockupProduct.webp
galleryImages: []
alt: alt descripció de la foto
slug: stoppers
category: publicitario-oficina
sku: 01-OFICI-00010
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Stoppers
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Stoppers
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.webp'
  sku: 01-OFICI-00010
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Stoppers
---
## Stoppers
