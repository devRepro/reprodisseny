---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/tarjetas-pvc.webp
galleryImages: []
alt: alt descripció de la foto
slug: tarjetas-pvc
category: publicitario-oficina
sku: 01-OFICI-0013
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Tarjetas de pvc
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Tarjetas de pvc
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/tarjetas-pvc.webp'
  sku: 01-OFICI-0013
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Tarjetas de pvc
---
## Tarjetas de pvc
