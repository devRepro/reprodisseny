---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/mockupProduct.web
galleryImages: []
alt: alt descripció de la foto
slug: imanes
category: publicitario-oficina
sku: 01-OFICI-0012
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Imanes
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Imanes
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.web'
  sku: 01-OFICI-0012
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Imanes
---
## Imanes
