---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/mockupProduct.web
galleryImages: []
alt: alt descripció de la foto
slug: figuras-arbol-navidad
category: eventos
sku: 01-EVEN-0018
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Figuras árbol de navidad
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Figuras árbol de navidad
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/mockupProduct.web'
  sku: 01-EVEN-0018
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Figuras árbol de navidad
---
## Figuras árbol de navidad
