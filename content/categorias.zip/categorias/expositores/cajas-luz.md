---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/Backlight.webp
galleryImages: []
alt: alt descripció de la foto
slug: cajas-luz
category: expositores
sku: 01-EXPO-0010
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Cajas de luz
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Cajas de luz
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/Backlight.webp'
  sku: 01-EXPO-0010
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Cajas de luz
---
## Cajas de luz
