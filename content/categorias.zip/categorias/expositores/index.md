---
metaTitle: ''
metaDescription: ''
keywords: |-
  Diseño de stands para ferias​
  Expositores personalizados para puntos de venta​
  Roll-ups publicitarios​Semrus
  Displays promocionales​
  Expositores portátiles para eventos'
searchTerms: ''
image: Estructuras-exposicion.png
galleryImages: []
alt: Expositores impresos personalizados para ferias y puntos de venta en Cataluña
slug: expositores
schemaType: Product
featured: false
order: 0
type: categoria
title: Expositores impresos para punto de venta y eventos | Repro Disseny
description: >-
  Stoppers, PLV, displays y peanas de cartón. Expositores personalizados para
  destacar en retail, showrooms y ferias.
category: ''
sku: ''
price: 0
brand: ''
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
nav: Expositores impresos para punto de venta y eventos
---
# Expositores impresos para punto de venta y eventos | Repro Disseny
