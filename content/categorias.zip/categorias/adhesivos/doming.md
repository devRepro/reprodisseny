---
metaTitle: ''
metaDescription: ''
keywords: ''
searchTerms: ''
image: /img/productos/Carteles.webp
galleryImages: []
alt: alt descripció de la foto
slug: doming
category: adhesivos
sku: 01-ADHE-0005
price: 0
brand: Reprodisseny
inStock: true
formFields: []
ratingValue: 0
reviewCount: 0
schemaType: Product
type: producto
title: Doming ( gota resina )
description: descripción genérica de mi producto para probar
priceCurrency: EUR
schema:
  '@type': Product
  name: Doming ( gota resina )
  description: descripción genérica de mi producto para probar
  image: 'https://reprodisseny.com/img/productos/Carteles.webp'
  sku: 01-ADHE-0005
  brand:
    '@type': Organization
    name: Repro Disseny
  offers:
    '@type': Offer
    price: 0
    priceCurrency: EUR
    availability: 'https://schema.org/InStock'
nav: Doming ( gota resina )
---
## Doming ( gota resina )
